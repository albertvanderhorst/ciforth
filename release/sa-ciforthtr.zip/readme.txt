Standalone ciforth with sector and track I/O.
Requirements 80386 + , reasonably modern hard disk.

Content:
   alonetr.ps  : ciforth documentation for stand alone 32 bits Forth
   fdimage     : boot image with kernel and blocks
   readme.txt  : this file
   rawrite.exe : to write a floppy on DOS / Windows
   rawrite3.doc : doc of the above

To install ciforth on a 3" HD floppy under DOS:
    use the program rawrite.exe (supplied) to write
    the file ``FDIMAGE'' to a 3" HD floppy.

To install ciforth on a 3" HD floppy under Linux:
    cp fdimage /dev/fd0H1440

You have now a bootable floppy with a forth in protected mode
and 4 Mbyte core and 1 Mbyte worth of blocks.

To install ciforth on a hard disk system:
    boot from the floppy
    1 LOAD
    REQUIRE INSTALL-FORTH-ON-HD

    Keep typing `Y' as long as you agree.

Your system now boots from your hard disk into a 32 bits
protected mode Forth that uses all your core and can access the
disk inasfar the BIOS allows it, up to 8 Terabyte (less on older
system.)

ciforth is a close-to-ISO Forth supplied under the terms as
set forth in appendix C of the documentation supplied.
More ciforth systems at the site below.

--
Albert van der Horst,Oranjestr 8,3511 RA UTRECHT,THE NETHERLANDS
To suffer is the prerogative of the strong. The weak -- perish.
albert@spenarnc.xs4all.nl     http://home.hccnet.nl/a.w.m.van.der.horst
